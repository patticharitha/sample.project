console.log("a person vote eligibility")
let a=17
if (a<18){
    console.log("you cannot vote")
}
else{
    console.log("you can vote")
}