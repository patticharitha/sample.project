console.log("check number is even or odd")
let n=18
if(n%2==0){
    console.log("number is even:",n)
}
else{
    console.log("number is odd:",n)
}