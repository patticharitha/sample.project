console.log("check student is pass or fail")
let marks=33
if(marks>33){
    console.log("pass");

}
else{
    console.log("fail");
}